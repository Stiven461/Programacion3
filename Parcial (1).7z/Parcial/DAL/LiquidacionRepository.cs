﻿using Entity;
using Parcial;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace DAL
{
    public class LiquidacionRepository
    {
        private readonly string FileName = "Liquidacion.txt";
        public void Guardar(Liquidacion liquidacion)
        {
            FileStream file = new FileStream(FileName, FileMode.Append);
            StreamWriter writer = new StreamWriter(file);
            writer.WriteLine($"{liquidacion.Identificacion};{liquidacion.Nombre};{liquidacion.IngresosAnuales};{liquidacion.GastosAnuales};{liquidacion.TiempoFuncionamiento};{liquidacion.GanaciasAnuales};{liquidacion.tarifa} ");
            writer.Close();
            file.Close();

        }
        public Liquidacion Buscar(string identificacion)
        {
            List<Liquidacion> personas = ConsultarTodos();
            foreach (var item in personas)
            {
                if (EsEncontrado(item.Identificacion, identificacion))
                {
                    return item;
                }
            }
            return null;
        }
        private bool EsEncontrado(string identificacioRegistrada, string identificacionBuscada)
        {
            return identificacioRegistrada == identificacionBuscada;
        }
        public List<Liquidacion> ConsultarTodos()
        {
            List<Liquidacion> personas = new List<Liquidacion>();
            FileStream file = new FileStream(FileName, FileMode.OpenOrCreate, FileAccess.Read);
            StreamReader reader = new StreamReader(file);
            string linea = string.Empty;
            while ((linea = reader.ReadLine()) != null)
            {

                Liquidacion persona = Map(linea);
                personas.Add(persona);
            }
            reader.Close();
            file.Close();
            return personas;
        }
        private Liquidacion Map(string linea)
        {
            Liquidacion persona = new Liquidacion();
            char delimiter = ';';
            string[] matrizPersona = linea.Split(delimiter);
            persona.Identificacion = matrizPersona[0];
            persona.Nombre = matrizPersona[1];
            persona.IngresosAnuales = int.Parse(matrizPersona[2]);
            persona.GastosAnuales = decimal.Parse(matrizPersona[3]);
            persona.TiempoFuncionamiento = decimal.Parse(matrizPersona[4]);
            persona.GanaciasAnuales = decimal.Parse(matrizPersona[5]);
            persona.tarifa = decimal.Parse(matrizPersona[6]);
            return persona;
        }
        public void Eliminar(string identificacion)
        {
            List<Liquidacion> personas = new List<Liquidacion>();
            personas = ConsultarTodos();
            FileStream file = new FileStream(FileName, FileMode.Create);
            file.Close();
            foreach (var item in personas)
            {
                if (!EsEncontrado(item.Identificacion, identificacion))
                {
                    Guardar(item);
                }

            }

        }
        public void Modificar(Liquidacion personaOld, Liquidacion personaNew)
        {
            List<Liquidacion> personas = new List<Liquidacion>();
            personas = ConsultarTodos();
            FileStream file = new FileStream(FileName, FileMode.Create);
            file.Close();
            foreach (var item in personas)
            {
                if (!EsEncontrado(item.Identificacion, personaOld.Identificacion))
                {
                    Guardar(item);
                }
                else
                {
                    Guardar(personaNew);
                }

            }

        }
        public List<Liquidacion> FiltroPorNombre(string nombre)
        {
            return ConsultarTodos().Where(p => p.Nombre.Contains(nombre)).ToList();
        }
    }
}
