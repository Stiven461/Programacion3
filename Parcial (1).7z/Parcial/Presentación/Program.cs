﻿using System;
using BLL;
using Entity;
using Parcial;

namespace Presentación
{
    class Program
    {
        static void Main(string[] args)
        {
            bool seguir = true;
            int opcion = -1;
            while (opcion != -1) {
                Console.WriteLine("Digite la opcion");
                Console.WriteLine("1. Guardar Liquidacion");
                Console.WriteLine("2. Consultar Liquidacion");
                Console.WriteLine("1. Eliminar Liquidacion");
                Console.WriteLine("1. Salir");

                switch (opcion) 
                {
                    case 1:
                        Console.WriteLine("Guardar selecionado");
                        Guardar();
                        break;
                    case 2:
                        Console.WriteLine("Consutlar selecionado");
                        break;
                    case 3:
                        Console.WriteLine("Eliminar selecionado");
                        Eliminar();
                        break;
                }
            }
        }

        private static void Guardar() {
            string identificacion;
            string nombre;
            decimal ingresosAnuales;
            decimal gastosAnuales;
            decimal tiempoFuncionamiento;

            Console.WriteLine("Digite la identificacion");
            identificacion = Console.ReadLine();

            Console.WriteLine("Digite el nombre");
            nombre = Console.ReadLine();

            Console.WriteLine("Digite el los ingresos anuales");
            ingresosAnuales = decimal.Parse(Console.ReadLine());

            Console.WriteLine("Digite la los gastos anuales");
            gastosAnuales = decimal.Parse(Console.ReadLine());

            Console.WriteLine("Digite el timepo de funcionamiento en años");
            tiempoFuncionamiento = decimal.Parse(Console.ReadLine());

            Liquidacion liquidacion = new Liquidacion(identificacion, nombre, ingresosAnuales, gastosAnuales,tiempoFuncionamiento);
            LiquidacionService liquidacionService = new LiquidacionService();
            string message = liquidacionService.Guardar(liquidacion);
            Console.WriteLine($"Su Tarifa es {liquidacion.tarifa} " + message);
        }

        private static void Consultar(LiquidacionService personaService)
        {
            ConsultaLiquidacionResponse consultaLiquidacionResponse = personaService.ConsultarTodos();
            if (consultaLiquidacionResponse.Encontrado == true)
            {
                Console.WriteLine("Lista de Personas");
                foreach (var item in consultaLiquidacionResponse.Liquidaciones)
                {
                    Console.WriteLine(item.ToString());
                }
            }
            else
            {
                Console.WriteLine(consultaLiquidacionResponse.Message);
            }
        }
        private static void Eliminar() { }
    }
}