﻿namespace Parcial
{
    public  class Liquidacion
    {
        public Liquidacion(string identificacion, string nombre, decimal ingresosAnuales, decimal gastosAnuales, decimal tiempoFuncionamiento)
        {
            Identificacion = identificacion;
            Nombre = nombre;
            IngresosAnuales = ingresosAnuales;
            GastosAnuales = gastosAnuales;
            GanaciasAnuales = this.IngresosAnuales - this.GastosAnuales;
            TiempoFuncionamiento = tiempoFuncionamiento;
        }

        public Liquidacion() { }

        public string Identificacion { get; set; }
        public string Nombre { get; set; }
        public decimal IngresosAnuales { get; set; }
        public decimal GastosAnuales { get; set; }
        public decimal TiempoFuncionamiento { get; set; }

        public decimal GanaciasAnuales { get; set; }
        public decimal tarifa { get; set; }

        public override string ToString()
        {
            return $"Identificacion: {Identificacion} - Nombre:{Nombre}-IngresosAnuales:{IngresosAnuales} -GastosAnuales:{GastosAnuales}-GanaciasAnuales: {GanaciasAnuales}  -Tarifa: {tarifa} ";
        }
    }


}