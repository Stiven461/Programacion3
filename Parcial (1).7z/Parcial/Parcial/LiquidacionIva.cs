﻿using Parcial;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity
{
    public class LiquidacionIva : Liquidacion
    {

        decimal UVT = 30000;
        public LiquidacionIva(string identificacion, string nombre, decimal ingresosAnuales, decimal gastosAnuales, decimal tiempoFuncionamiento) : base(identificacion, nombre, ingresosAnuales, gastosAnuales, tiempoFuncionamiento)
        {
            tarifa = CalcularTarifa();
        }

        public int CalcularTarifa() 
        {
            if (GanaciasAnuales < 0)
            {
                return  0;
            }
            else if (GanaciasAnuales < (100 * UVT))
            {
                return 5;
            }
            else if (GanaciasAnuales >= (100 * UVT) || GanaciasAnuales <= (200 * UVT))
            {
                return 10;

            }
            else if (GanaciasAnuales >= (200 * UVT)) {
                return 15;
            }
            return -1;
        }

    }
}
