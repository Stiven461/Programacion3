﻿using Parcial;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity
{
    public class LiquidacionNoIva : Liquidacion
    {
        decimal UVT = 30000;
        public LiquidacionNoIva(string identificacion, string nombre, decimal ingresosAnuales, decimal gastosAnuales, decimal tiempoFuncionamiento) : base(identificacion, nombre, ingresosAnuales, gastosAnuales, tiempoFuncionamiento)
        {
            tarifa = CalcularTarifa();
        }

        public int CalcularTarifa() {
            if (GanaciasAnuales > (100 * UVT))
            {
                if (TiempoFuncionamiento > 6) {
                    return  1;
                } else if (TiempoFuncionamiento >= 6 && TiempoFuncionamiento < 10) {
                    return 2;
                } else if (TiempoFuncionamiento >=10) {
                    return 3;
                }
            }
            else {
                return 0;
            }
            return -1;
        }
    }
}
