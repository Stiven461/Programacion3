﻿using Parcial;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity
{
    public  class LiquidacionRST : Liquidacion
    {
        decimal UVT = 30000;
        public LiquidacionRST(string identificacion, string nombre, decimal ingresosAnuales, decimal gastosAnuales, decimal tiempoFuncionamiento) : base(identificacion, nombre, ingresosAnuales, gastosAnuales, tiempoFuncionamiento)
        {
            tarifa = CalcularTarifa();
        }

        public decimal CalcularTarifa() {
            decimal porcentaje = 0.5m;
            if (GanaciasAnuales > (50 * UVT)) { 
                return GanaciasAnuales * porcentaje;
            }
            return 0;
        }
    }
}
