﻿using DAL;
using Entity;
using Parcial;

namespace BLL
{
    public class LiquidacionService
    {
        private readonly LiquidacionRepository LiquidacionRepository;
        public LiquidacionService()
        {
            LiquidacionRepository = new LiquidacionRepository();
        }
        public string Guardar(Liquidacion liquidacion)
        {
            try
            {

                if (LiquidacionRepository.Buscar(liquidacion.Identificacion) == null)
                {
                    LiquidacionRepository.Guardar(liquidacion);
                    return $"se han guardado Satisfactoriamente los datos de: {liquidacion.Nombre} ";
                }
                else
                {
                    return $"Lo sentimos, con la Identificación {liquidacion.Identificacion} ya se encuentra registrada";
                }
            }
            catch (Exception e)
            {

                return $"Error de la Aplicacion: {e.Message}";
            }
        }
        public string Eliminar(string identificacion)
        {
            try
            {
                if (LiquidacionRepository.Buscar(identificacion) != null)
                {
                    LiquidacionRepository.Eliminar(identificacion);
                    return ($"se han Eliminado Satisfactoriamente los datos de la liquidacion con Identificación: {identificacion} ");
                }
                else
                {
                    return ($"Lo sentimos, no se encuentra registrada una liquidacion con Identificacion {identificacion}");
                }
            }
            catch (Exception e)
            {

                return $"Error de la Aplicacion: {e.Message}";
            }

        }
        public LiquidacionResponse BuscarPorIdentificacion(string identificacion)
        {

            try
            {
                Liquidacion liquidacion = LiquidacionRepository.Buscar(identificacion);
                if (liquidacion != null)
                {
                    return new LiquidacionResponse(liquidacion);
                }
                else
                {
                    return new LiquidacionResponse("La liquidacion buscada no se encuentra Registrada");
                }

            }
            catch (Exception e)
            {

                return new LiquidacionResponse("Error de Aplicacion: " + e.Message);
            }

        }
        public ConsultaLiquidacionResponse ConsultarTodos()
        {

            try
            {
                List<Liquidacion> liquidaciones = LiquidacionRepository.ConsultarTodos();
                if (liquidaciones != null)
                {
                    return new ConsultaLiquidacionResponse(liquidaciones);
                }
                else
                {
                    return new ConsultaLiquidacionResponse("La liquidacion buscada no se encuentra Registrada");
                }

            }
            catch (Exception e)
            {

                return new ConsultaLiquidacionResponse("Error de Aplicacion: " + e.Message);
            }
        }
    }

    public class LiquidacionResponse
    {
        public Liquidacion liquidacion { get; set; }
        public string Message { get; set; }
        public bool Encontrado { get; set; }

        public LiquidacionResponse(Liquidacion persona)
        {
            liquidacion = new Liquidacion();
            liquidacion = persona;
            Encontrado = true;
        }
        public LiquidacionResponse(string message)
        {
            Message = message;
            Encontrado = false;
        }
    }
    public class ConsultaLiquidacionResponse
    {
        public List<Liquidacion> Liquidaciones { get; set; }
        public string Message { get; set; }
        public bool Encontrado { get; set; }

        public ConsultaLiquidacionResponse(List<Liquidacion> liquidaciones)
        {
            Liquidaciones = new List<Liquidacion>();
            Liquidaciones = liquidaciones;
            Encontrado = true;
        }
        public ConsultaLiquidacionResponse(string message)
        {
            Message = message;
            Encontrado = false;
        }
    }
}
