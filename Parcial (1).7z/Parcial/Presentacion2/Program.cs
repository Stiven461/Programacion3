﻿using System;
using BLL;
using Entity;
using Parcial;

namespace Presentación
{
    class Program
    {
        static void Main(string[] args)
        {
            bool seguir = true;
            int opcion = -1;
            while (seguir) 
            {
                Console.WriteLine("Digite la opcion");
                Console.WriteLine("1. Guardar Liquidacion");
                Console.WriteLine("2. Consultar Liquidacion");
                Console.WriteLine("3. Eliminar Liquidacion");
                Console.WriteLine("4. Salir");

                opcion = int.Parse(Console.ReadLine());
                switch (opcion)
                {
                    case 1:
                        Console.WriteLine("Guardar selecionado");
                        Guardar();
                        break;
                    case 2:
                        Console.WriteLine("Consutlar selecionado");
                        LiquidacionService liquidacionService = new LiquidacionService();
                        Consultar(liquidacionService);
                        break;
                    case 3:
                        Console.WriteLine("Eliminar selecionado");
                        LiquidacionService liquidacionService2 = new LiquidacionService();
                        Eliminar(liquidacionService2);
                        break;
                    case 4:
                        Console.WriteLine("Hasta Pronto");
                        seguir = false;
                        break;
                }
            }
        }

        private static void Guardar()
        {
            string identificacion;
            string nombre;
            decimal ingresosAnuales;
            decimal gastosAnuales;
            decimal tiempoFuncionamiento;
            int tipores;

            Console.WriteLine("Digite la identificacion");
            identificacion = Console.ReadLine();

            Console.WriteLine("Digite el nombre");
            nombre = Console.ReadLine();

            Console.WriteLine("Digite el los ingresos anuales");
            ingresosAnuales = decimal.Parse(Console.ReadLine());

            Console.WriteLine("Digite la los gastos anuales");
            gastosAnuales = decimal.Parse(Console.ReadLine());

            Console.WriteLine("Digite el timepo de funcionamiento en años");
            tiempoFuncionamiento = decimal.Parse(Console.ReadLine());

            Console.WriteLine("Digite tipo de responsabilidad ");
            Console.WriteLine("1. responsable de IVA ");
            Console.WriteLine("2. no responsable de IVA ");
            tipores = int.Parse(Console.ReadLine());

            if (tipores == 1)
            {
                LiquidacionIva liquidacion = new LiquidacionIva(identificacion, nombre, ingresosAnuales, gastosAnuales, tiempoFuncionamiento);
                LiquidacionService liquidacionService = new LiquidacionService();
                string message = liquidacionService.Guardar(liquidacion);
                Console.WriteLine($"Su Tarifa es {liquidacion.tarifa} " + message);
            }
            else if (tipores == 2) {
                LiquidacionNoIva liquidacion = new LiquidacionNoIva(identificacion, nombre, ingresosAnuales, gastosAnuales, tiempoFuncionamiento);
                LiquidacionService liquidacionService = new LiquidacionService();
                string message = liquidacionService.Guardar(liquidacion);
                Console.WriteLine($"Su Tarifa es {liquidacion.tarifa} " + message);
            } else if (tipores == 3) {
                LiquidacionRST liquidacion = new LiquidacionRST(identificacion, nombre, ingresosAnuales, gastosAnuales, tiempoFuncionamiento);
                LiquidacionService liquidacionService = new LiquidacionService();
                string message = liquidacionService.Guardar(liquidacion);
                Console.WriteLine($"Su Tarifa es {liquidacion.tarifa} " + message);
            }
        }

        private static void Consultar(LiquidacionService personaService)
        {
            ConsultaLiquidacionResponse consultaPersonaResponse = personaService.ConsultarTodos();
            if (consultaPersonaResponse.Encontrado == true)
            {
                Console.WriteLine("Lista de Personas");
                foreach (var item in consultaPersonaResponse.Liquidaciones)
                {
                    Console.WriteLine(item.ToString());
                }
            }
            else
            {
                Console.WriteLine(consultaPersonaResponse.Message);
            }
        }
        private static void Eliminar(LiquidacionService personaService)
        {
            Consultar(personaService);
            Console.WriteLine("------------------------");
            Console.WriteLine("Ingrese el Id que desea eliminar");
            string id = (Console.ReadLine());
            personaService.Eliminar(id);
            Console.WriteLine("------------------------");
            Consultar(personaService);
        }
    }
}